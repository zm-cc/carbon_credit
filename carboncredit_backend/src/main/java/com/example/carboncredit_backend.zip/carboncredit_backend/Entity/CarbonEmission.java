package com.example.carboncredit_backend.Entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Setter
@Getter
@Table(name = "carbon_emissions")
public class CarbonEmission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "company_id")
    private int company_id;

    @Column(name = "emission_amount")
    private float emission_amount;

    @Column(name = "emission_date")
    private String emission_date;
}
