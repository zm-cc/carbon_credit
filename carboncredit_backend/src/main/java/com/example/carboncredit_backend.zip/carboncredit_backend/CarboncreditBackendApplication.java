package com.example.carboncredit_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarboncreditBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarboncreditBackendApplication.class, args);
    }

}
