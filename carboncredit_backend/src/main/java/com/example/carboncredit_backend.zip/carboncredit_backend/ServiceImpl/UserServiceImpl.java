package com.example.carboncredit_backend.ServiceImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.example.carboncredit_backend.Dao.UserDao;
import com.example.carboncredit_backend.Entity.User;
import com.example.carboncredit_backend.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserDao userDao;
    public String check(String username, String password) {
        User u=null;
        u = userDao.check(username);
        if (u == null)
            return "1";    //找不到用户
        //Base64.Decoder decoder=Base64.getDecoder();
        //byte[] tmp=decoder.decode(u.getPassword());    //解密
        String pwd=u.getPassword();
        if (!Objects.equals(pwd, password))
            return "2";    //密码错误
        String email = u.getEmail();
        System.out.println(email);
        ArrayList<String> con = new ArrayList<>();
        con.add(String.valueOf(u.getUser_id()));    //用户id
        con.add(u.getUsername());    //用户名
        con.add(u.getImage());    //用户头像
        return JSON.toJSONString(con, SerializerFeature.BrowserCompatible);
    }

    public int create(String user_name, String password,int age, String email, String image_url)
    {
        return userDao.create(user_name,password,age,email,image_url);
    }
}
