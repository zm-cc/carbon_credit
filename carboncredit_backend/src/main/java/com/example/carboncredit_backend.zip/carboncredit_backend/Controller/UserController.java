package com.example.carboncredit_backend.Controller;

import com.example.carboncredit_backend.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@Component
public class UserController {
    @Autowired
    UserService userService;

    @RequestMapping("/CheckUser")
    @ResponseBody
    public String check(@RequestBody Map map) {     //登录时检测用户名与密码
        String username = String.valueOf(map.get("username"));
        String password = String.valueOf(map.get("password"));
        System.out.println(username);
        System.out.println(password);
        return userService.check(username, password);
    }

    @RequestMapping("/CreateUser")
    @ResponseBody
    public String create(@RequestBody Map map) {    //注册新用户
        String username = String.valueOf(map.get("username"));
        String password = String.valueOf(map.get("password"));
        String tmp = String.valueOf(map.get("age"));
        int age = Integer.parseInt(tmp);
        String image = String.valueOf(map.get("image"));
        String email = String.valueOf(map.get("email"));
        int uid = userService.create(username, password, age, image, email);
        System.out.println(uid);
        return String.valueOf(uid);
    }

    /*@RequestMapping("/AddBalance")
    @ResponseBody
    public String add(@RequestBody Map map) {    //充值
        String tmp1 = String.valueOf(map.get("user_id"));
        int user_id = Integer.parseInt(tmp1);
        String tmp2 = String.valueOf(map.get("money"));
        int balance = Integer.parseInt(tmp2);
        if (userService.add(user_id, balance))
            return "1";
        else
            return "0";
    }

    @RequestMapping("/GetSomeInfo")
    @ResponseBody
    public String getSomeInfo(@RequestBody Map map) {    //余额、发起数、参与数
        String tmp = String.valueOf(map.get("user_id"));
        int user_id = Integer.parseInt(tmp);
        return userService.getSomeInfo(user_id);
    }

    @RequestMapping("/GetUsername")
    @ResponseBody
    public String getUsername(@RequestBody Map map) {
        String tmp = String.valueOf(map.get("user_id"));
        int user_id = Integer.parseInt(tmp);
        return userService.getUsername(user_id);
    }*/
}
