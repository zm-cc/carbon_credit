package com.example.carboncredit_backend.Service;

public interface UserService {
    String check(String username, String password);
    int create(String user_name, String password,int age ,String email, String image_url);
}
